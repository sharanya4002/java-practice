//characterStreams
import java.io.*;
import java.util.*;
class CS
{
	public static void main(String args[]) throws Exception
	{
		String path ="C:\\Users\\Shara\\OneDrive\\Desktop\\File-Handling\\characterData.txt";
		File f = new File(path);

		FileWriter fw = new FileWriter(f);
		Scanner sc = new Scanner(System.in);
		String data = sc.nextLine();
		
		fw.write(data);

		fw.close();

		FileReader fr = new FileReader(f);
		int x=0;
		while(true)
		{
			x = fr.read();
			if(x ==-1)
			{
				break;
			}
			else
			{
				System.out.print((char)x);
			}
		}
		
	}
}
