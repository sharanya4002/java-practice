//byteStreams
import java.io.*;
import java.util.Scanner;
class BS
{
	public static void main(String args[]) throws Exception
	{
		String path="C:\\Users\\Shara\\OneDrive\\Desktop\\File-Handling\\byteData.txt";
		File f = new File(path);

		f.createNewFile();
		
		FileOutputStream fos = new FileOutputStream(f);
		Scanner sc = new Scanner(System.in);
		String data = sc.nextLine();
		
		byte arr[] = data.getBytes();
			
		fos.write(arr);

		FileInputStream fis = new FileInputStream(f);
			
		int x=0;
		while(true)
		{
			x=fis.read();
			if(x==-1)
				break;
			else
				System.out.print((char)x);
		}	
		
		
	}
}