import java.io.*;
import java.util.*;
class B
{
	public static void main(String []args) throws Exception
	{
		String path1 = "C:\\Users\\Shara\\OneDrive\\Desktop\\ByteOs\\mars1.txt";
		String path2 = "C:\\Users\\Shara\\OneDrive\\Desktop\\ByteOs\\mars2.txt";
		String path3 = "C:\\Users\\Shara\\OneDrive\\Desktop\\ByteOs\\mars3.txt";
		String path4  = "C:\\Users\\Shara\\OneDrive\\Desktop\\ByteOs\\mars4.txt";

		
		FileInputStream fis1 = new FileInputStream(path1);
		FileInputStream fis2 = new FileInputStream(path2);
		FileInputStream fis3 = new FileInputStream(path3);
		FileInputStream fis4 = new FileInputStream(path4);

		/*SequenceInputStream seq = new SequenceInputStream(fis1,fis2);
		
		int x =0;
		
		while(true)
		{
			x=seq.read();
			if(x==-1)
				break;
			else
				System.out.print((char)x);
		}*/


		Vector<FileInputStream> v = new Vector<>();
		
		v.addElement(fis1);
		v.addElement(fis2);
		v.addElement(fis3);	
		v.addElement(fis4);
		
		Enumeration en =  v.elements();

		SequenceInputStream seq = new SequenceInputStream(en);

		int x =0;
		while(true)
		{
			x = seq.read();
			if(x ==-1)
				break;
			else
				System.out.print((char)x);
		}
		
	}
}
	