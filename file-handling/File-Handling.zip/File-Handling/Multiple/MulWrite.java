import java.io.*;
class A
{
	public static void main(String args[]) throws Exception
	{
		String path1 = "C:\\Users\\Shara\\OneDrive\\Desktop\\ByteOs\\mars1.txt";
		String path2 = "C:\\Users\\Shara\\OneDrive\\Desktop\\ByteOs\\mars2.txt";
		String path3 = "C:\\Users\\Shara\\OneDrive\\Desktop\\ByteOs\\mars3.txt";
		String path4  = "C:\\Users\\Shara\\OneDrive\\Desktop\\ByteOs\\mars4.txt";
		String path5 = "C:\\Users\\Shara\\OneDrive\\Desktop\\ByteOs\\mars5.txt";


		File f1 = new File(path1);
		File f2 = new File(path2);
		File f3 = new File(path3);
		File f4 = new File(path4);
		File f5 = new File(path5);

		f1.createNewFile();
		f2.createNewFile();
		f3.createNewFile();
		f4.createNewFile();
		f5.createNewFile();

		FileOutputStream fos1 = new FileOutputStream(f1);
		FileOutputStream fos2 = new FileOutputStream(f2);
		FileOutputStream fos3 = new FileOutputStream(f3);
		FileOutputStream fos4 = new FileOutputStream(f4);
		FileOutputStream fos5 = new FileOutputStream(f5);


		ByteArrayOutputStream baos = new ByteArrayOutputStream();

		String data = "Sharanya";
		byte ar[] = data.getBytes();

		baos.write(ar);
		
		baos.writeTo(fos1);
		baos.writeTo(fos2);
		baos.writeTo(fos3);
		baos.writeTo(fos4);
		baos.writeTo(fos5);
		
	}
}