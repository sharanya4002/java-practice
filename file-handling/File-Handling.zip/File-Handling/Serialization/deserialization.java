import java.util.Scanner;
import java.io.*;
class B
{
	public static void main(String args[]) throws Exception
	{
		FileInputStream fis = new FileInputStream("productInfo.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);

		Product p = (Product)ois.readObject();
			
		System.out.print(p.pid +" "+p.pname+" "+p.price);
	}
}
		
		