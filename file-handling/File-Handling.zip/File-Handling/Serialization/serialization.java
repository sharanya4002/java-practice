import java.io.*;
import java.util.Scanner;
class Product implements Serializable
{
	int pid;
	String pname;
	transient double price;
	Product(int pid,String pname,double price)
	{
		this.pid =pid;
		this.pname = pname;
		this.price = price;
	}
	
}
class A
{
	public static void main(String args[]) throws Exception
	{
		Scanner sc = new Scanner(System.in);
		Product p1 = new Product(sc.nextInt(),sc.next(),sc.nextDouble());
	 
		FileOutputStream fos = new FileOutputStream("productInfo.txt");
		ObjectOutputStream out = new ObjectOutputStream(fos);
		
		out.writeObject(p1);
		out.close();
	}
}