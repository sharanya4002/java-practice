//bufferedStreams

import java.util.*;
import java.io.*;
class BS
{
	public static void main(String args[]) throws Exception
	{
		String path = "C:\\Users\\Shara\\OneDrive\\Desktop\\File-Handling\\characterData.txt";
		File f = new File(path);

		FileOutputStream fos = new FileOutputStream(f);
		BufferedOutputStream bos = new BufferedOutputStream(fos);

		Scanner sc = new Scanner(System.in);
	
		String data = sc.nextLine();
		
		byte arr[] = data.getBytes();
		bos.write(arr);

		String data1 = sc.nextLine();
		byte ar2[] = data1.getBytes();
		bos.write(ar2);

		bos.flush();
	
		bos.close();
		fos.close();
		sc.close();

		FileInputStream fis = new FileInputStream(f);
		BufferedInputStream bis = new BufferedInputStream(fis);
		
		int x =0;
		while(true)
		{
			x = bis.read();

			if(x == -1)
			{
				break;
			}
			else
			{
				System.out.print((char)x);
			}
		}		
	}
}